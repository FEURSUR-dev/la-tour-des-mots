# La Tour des Mots — Android APK

Application Android familiale de jeu de lettres. Le principe reprend le jeu du pendu sans pendaison : après 10 erreurs/coûts, l’échafaudage disparaît et Bibo tombe de façon comique sur les fesses.

## Ce dépôt produit bien un APK

Le code du jeu se trouve dans `www/`. Capacitor l’intègre dans une application Android native. Le workflow GitHub Actions `.github/workflows/build-apk.yml` construit automatiquement un fichier `.apk` installable.

## Publication sur GitHub — méthode la plus simple

1. Créer un nouveau dépôt GitHub public ou privé, par exemple `la-tour-des-mots`.
2. Envoyer **tout le contenu de ce dossier à la racine du dépôt**.
3. Valider le commit sur la branche `main`.
4. Ouvrir l’onglet **Actions** du dépôt.
5. Ouvrir le workflow **Construire APK Android**.
6. Si nécessaire, cliquer sur **Run workflow**. Un push sur `main` lance aussi le build automatiquement.
7. Quand le workflow est vert, ouvrir son exécution.
8. Dans **Artifacts**, télécharger `La-Tour-des-Mots-APK`.
9. Décompresser l’artefact : il contient `La-Tour-des-Mots-debug.apk`.
10. Copier l’APK sur un téléphone Android et l’installer. Android peut demander l’autorisation d’installer une application provenant de cette source.

Le build `debug` est signé automatiquement avec une clé de débogage et convient pour tester et partager l’application en dehors du Play Store. Pour une publication Play Store ou une distribution officielle durable, créer ensuite une clé de signature `release` et générer un APK/AAB signé.

## Compilation locale sur Windows

Pré-requis : Node.js 22+ et Android Studio avec le SDK Android.

```bash
npm install
npm run android:prepare
npm run android:open
```

Android Studio ouvre le projet natif. Pour produire un APK installable, utiliser **Build > Generate App Bundles or APKs > Generate APKs** (le libellé exact peut varier selon la version d’Android Studio).

On peut aussi tenter la compilation en ligne de commande :

```bash
npm run android:debug
```

APK attendu :

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

## Après une modification du jeu

Modifier les fichiers dans `www/`, puis :

```bash
npm run android:prepare
```

Cela synchronise le nouveau jeu avec Android.

## Structure

```text
.
├── .github/workflows/build-apk.yml   # compilation automatique GitHub
├── capacitor.config.json             # configuration Android/Capacitor
├── package.json
├── scripts/                           # préparation et build
├── resources/                         # icône Android
└── www/                               # application complète
    ├── index.html
    ├── styles.css
    ├── app.js
    └── data/words.js
```

## Identité Android

- Nom : `La Tour des Mots`
- App ID : `pf.latourdesmots.app`
- Capacitor : `8.4.2`
- Android minSdk généré par Capacitor 8 : API 24


## Version 1.1.0

- correction de la zone « Ton prénom » sur téléphone ;
- mascotte déplacée en haut de l’échafaudage ;
- lecture du mot assurée par le moteur vocal natif Android via `@capacitor-community/text-to-speech`, avec secours Web Speech API ;
- bundling JavaScript automatique avec esbuild avant la synchronisation Capacitor.
