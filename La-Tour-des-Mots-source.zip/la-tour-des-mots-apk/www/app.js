import { LEVELS, THEMES, countWords, getWords } from './data/words.js'
import { TextToSpeech } from '@capacitor-community/text-to-speech'

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')
const MAX_MISTAKES = 10
const STORAGE_KEY = 'tour-des-mots-profile-v2'

const DEFAULT_PROFILE = {
  playerName: '',
  games: 0,
  wins: 0,
  streak: 0,
  bestStreak: 0,
  stars: 0,
  sound: true,
  music: true,
  reducedMotion: false,
  level: 'enfant',
  theme: 'animaux',
}

const state = {
  screen: 'home',
  level: 'enfant',
  theme: 'animaux',
  word: '',
  lastWord: '',
  guessed: [],
  mistakes: 0,
  hintUsed: false,
  round: 1,
  status: 'playing',
  profile: loadProfile(),
}

state.level = state.profile.level || 'enfant'
state.theme = state.profile.theme || 'animaux'

let audioContext = null
let toastTimer = null
let musicTimer = null
let musicStep = 0
let musicRunning = false
let musicMasterGain = null
const activeMusicSources = new Set()

// Mélodie traditionnelle « Korobeiniki », popularisée par les jeux de blocs.
// Elle est synthétisée directement par WebAudio : aucun fichier audio externe n'est nécessaire.
const MUSIC_UNIT = 0.40
const MUSIC_SEQUENCE = [
  [659.25, 1], [493.88, .5], [523.25, .5], [587.33, 1], [523.25, .5], [493.88, .5],
  [440.00, 1], [440.00, .5], [523.25, .5], [659.25, 1], [587.33, .5], [523.25, .5],
  [493.88, 1.5], [523.25, .5], [587.33, 1], [659.25, 1], [523.25, 1], [440.00, 1], [440.00, 2],

  [587.33, 1.5], [698.46, .5], [880.00, 1], [783.99, .5], [698.46, .5], [659.25, 1.5],
  [523.25, .5], [659.25, 1], [587.33, .5], [523.25, .5], [493.88, 1], [493.88, .5],
  [523.25, .5], [587.33, 1], [659.25, 1], [523.25, 1], [440.00, 1], [440.00, 2],

  [659.25, 1], [523.25, 1], [587.33, 1], [493.88, 1], [523.25, 1], [440.00, 1],
  [415.30, 1], [493.88, 2], [659.25, 1], [523.25, 1], [587.33, 1], [493.88, 1],
  [523.25, .5], [659.25, .5], [880.00, 1], [830.61, 1], [659.25, 2],
]

const app = document.querySelector('#app')
const overlayRoot = document.querySelector('#overlay-root')

function loadProfile() {
  try {
    return { ...DEFAULT_PROFILE, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}') }
  } catch {
    return { ...DEFAULT_PROFILE }
  }
}

function saveProfile() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.profile))
}

function foldChar(char = '') {
  return char
    .toUpperCase()
    .replaceAll('Œ', 'O')
    .replaceAll('Æ', 'A')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
}

function isLetter(char) {
  return /[A-ZÀ-ÖØ-öø-ÿŒÆ]/i.test(char)
}

function normalizedLetters(word) {
  return [...word].filter(isLetter).map(foldChar)
}

function uniqueLetters(word) {
  return [...new Set(normalizedLetters(word))]
}

function pickRandom(items, except = '') {
  if (!items.length) return ''
  if (items.length === 1) return items[0]
  let next = items[Math.floor(Math.random() * items.length)]
  while (next === except) next = items[Math.floor(Math.random() * items.length)]
  return next
}

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;')
}

function getAudioContext() {
  const AudioCtx = window.AudioContext || window.webkitAudioContext
  if (!AudioCtx) return null

  if (!audioContext) audioContext = new AudioCtx()

  if (audioContext.state === 'suspended') {
    audioContext.resume().catch(() => {})
  }

  return audioContext
}

function tone(freq, duration = 0.08, type = 'sine', delay = 0, volume = 0.12) {
  if (!state.profile.sound) return

  try {
    const ctx = getAudioContext()
    if (!ctx) return

    const start = ctx.currentTime + delay
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()

    osc.type = type
    osc.frequency.setValueAtTime(freq, start)

    gain.gain.setValueAtTime(0.0001, start)
    gain.gain.exponentialRampToValueAtTime(volume, start + 0.01)
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration)

    osc.connect(gain)
    gain.connect(ctx.destination)
    osc.start(start)
    osc.stop(start + duration + 0.03)
  } catch {
    // Le jeu reste utilisable même si WebAudio n'est pas disponible.
  }
}

function sweepTone(startFreq, endFreq, duration = 0.4, type = 'sine', delay = 0, volume = 0.06) {
  if (!state.profile.sound) return

  try {
    const ctx = getAudioContext()
    if (!ctx) return

    const start = ctx.currentTime + delay
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()

    osc.type = type
    osc.frequency.setValueAtTime(startFreq, start)
    osc.frequency.exponentialRampToValueAtTime(Math.max(30, endFreq), start + duration)

    gain.gain.setValueAtTime(0.0001, start)
    gain.gain.exponentialRampToValueAtTime(volume, start + 0.025)
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration)

    osc.connect(gain)
    gain.connect(ctx.destination)
    osc.start(start)
    osc.stop(start + duration + 0.03)
  } catch {
    // Aucun son si WebAudio n'est pas disponible.
  }
}

function softImpact(delay = 0) {
  if (!state.profile.sound) return

  try {
    const ctx = getAudioContext()
    if (!ctx) return

    const start = ctx.currentTime + delay

    // Petit « pouf » grave au moment où Bibo touche le sol.
    const osc = ctx.createOscillator()
    const oscGain = ctx.createGain()
    osc.type = 'sine'
    osc.frequency.setValueAtTime(105, start)
    osc.frequency.exponentialRampToValueAtTime(58, start + 0.16)
    oscGain.gain.setValueAtTime(0.0001, start)
    oscGain.gain.exponentialRampToValueAtTime(0.19, start + 0.008)
    oscGain.gain.exponentialRampToValueAtTime(0.0001, start + 0.19)
    osc.connect(oscGain)
    oscGain.connect(ctx.destination)
    osc.start(start)
    osc.stop(start + 0.21)

    // Une très courte bouffée de bruit donne l'impression d'un impact doux.
    const bufferSize = Math.max(1, Math.floor(ctx.sampleRate * 0.11))
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate)
    const data = buffer.getChannelData(0)
    for (let i = 0; i < bufferSize; i += 1) {
      const fade = 1 - i / bufferSize
      data[i] = (Math.random() * 2 - 1) * fade
    }

    const noise = ctx.createBufferSource()
    const noiseGain = ctx.createGain()
    const filter = ctx.createBiquadFilter()
    filter.type = 'lowpass'
    filter.frequency.value = 850
    noise.buffer = buffer
    noiseGain.gain.setValueAtTime(0.075, start)
    noiseGain.gain.exponentialRampToValueAtTime(0.0001, start + 0.11)
    noise.connect(filter)
    filter.connect(noiseGain)
    noiseGain.connect(ctx.destination)
    noise.start(start)
  } catch {
    // Aucun son si WebAudio n'est pas disponible.
  }
}

function ensureMusicMaster(ctx) {
  if (musicMasterGain) return musicMasterGain
  musicMasterGain = ctx.createGain()
  musicMasterGain.gain.value = 0.34
  musicMasterGain.connect(ctx.destination)
  return musicMasterGain
}

function playMusicNote(frequency, duration) {
  if (!state.profile.music || !musicRunning || !frequency) return

  try {
    const ctx = getAudioContext()
    if (!ctx) return
    const output = ensureMusicMaster(ctx)
    const now = ctx.currentTime
    const audible = Math.max(0.05, duration * 0.86)

    // Première voix : son carré très léger, façon console rétro.
    const lead = ctx.createOscillator()
    const leadGain = ctx.createGain()
    lead.type = 'square'
    lead.frequency.setValueAtTime(frequency, now)
    leadGain.gain.setValueAtTime(0.0001, now)
    leadGain.gain.exponentialRampToValueAtTime(0.045, now + 0.012)
    leadGain.gain.exponentialRampToValueAtTime(0.0001, now + audible)
    lead.connect(leadGain)
    leadGain.connect(output)

    // Deuxième voix très discrète pour donner un peu de rondeur.
    const soft = ctx.createOscillator()
    const softGain = ctx.createGain()
    soft.type = 'triangle'
    soft.frequency.setValueAtTime(frequency / 2, now)
    softGain.gain.setValueAtTime(0.0001, now)
    softGain.gain.exponentialRampToValueAtTime(0.022, now + 0.014)
    softGain.gain.exponentialRampToValueAtTime(0.0001, now + audible)
    soft.connect(softGain)
    softGain.connect(output)

    activeMusicSources.add(lead)
    activeMusicSources.add(soft)
    const cleanup = source => {
      activeMusicSources.delete(source)
      try { source.disconnect() } catch {}
    }
    lead.addEventListener('ended', () => cleanup(lead), { once: true })
    soft.addEventListener('ended', () => cleanup(soft), { once: true })

    lead.start(now)
    soft.start(now)
    lead.stop(now + audible + 0.025)
    soft.stop(now + audible + 0.025)
  } catch {
    // La musique reste facultative si WebAudio est indisponible.
  }
}

function scheduleNextMusicNote() {
  if (!state.profile.music || !musicRunning) return

  const [frequency, beats] = MUSIC_SEQUENCE[musicStep]
  const duration = MUSIC_UNIT * beats
  playMusicNote(frequency, duration)
  musicStep = (musicStep + 1) % MUSIC_SEQUENCE.length

  clearTimeout(musicTimer)
  musicTimer = setTimeout(scheduleNextMusicNote, Math.max(45, duration * 1000))
}

function startBackgroundMusic(reset = false) {
  if (!state.profile.music || document.visibilityState === 'hidden') return
  const ctx = getAudioContext()
  if (!ctx) return
  if (reset) musicStep = 0
  if (musicRunning) return

  musicRunning = true
  ensureMusicMaster(ctx)
  scheduleNextMusicNote()
}

function stopBackgroundMusic() {
  musicRunning = false
  clearTimeout(musicTimer)
  musicTimer = null

  for (const source of [...activeMusicSources]) {
    try { source.stop() } catch {}
    try { source.disconnect() } catch {}
  }
  activeMusicSources.clear()
}

function setMusicVolume(value = 0.34) {
  try {
    const ctx = getAudioContext()
    if (!ctx) return
    const output = ensureMusicMaster(ctx)
    output.gain.cancelScheduledValues(ctx.currentTime)
    output.gain.setTargetAtTime(value, ctx.currentTime, 0.035)
  } catch {}
}

function toggleBackgroundMusic() {
  state.profile.music = !state.profile.music
  saveProfile()

  if (state.profile.music) {
    startBackgroundMusic(true)
    notify('Musique activée')
  } else {
    stopBackgroundMusic()
    notify('Musique coupée')
  }

  render()
}

const sound = {
  correct() {
    tone(660, 0.07)
    tone(880, 0.08, 'sine', 0.06)
  },

  wrong() {
    tone(180, 0.12, 'triangle')
  },

  win() {
    ;[523, 659, 784, 1047].forEach((n, i) => tone(n, 0.16, 'sine', i * 0.09))
  },

  fall() {
    // Petit « wouu » descendant pendant la chute.
    sweepTone(520, 145, 0.55, 'sine', 0, 0.065)
    sweepTone(310, 95, 0.50, 'triangle', 0.07, 0.025)

    // L'impact est synchronisé avec l'image, environ 620 ms après le départ.
    softImpact(0.62)

    // Mini rebond sonore, très léger.
    tone(185, 0.07, 'triangle', 0.80, 0.045)
    tone(145, 0.09, 'triangle', 0.87, 0.035)
  },

  lose() {
    tone(205, 0.12, 'triangle', 0, 0.055)
    tone(165, 0.15, 'triangle', 0.10, 0.045)
  },

  click() {
    tone(420, 0.04)
  },
}

function notify(message) {
  let toast = document.querySelector('.toast')
  if (!toast) {
    toast = document.createElement('div')
    toast.className = 'toast'
    toast.setAttribute('role', 'status')
    document.body.appendChild(toast)
  }
  toast.textContent = message
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => toast.remove(), 1800)
}

function render() {
  document.documentElement.classList.toggle('reduce-motion', state.profile.reducedMotion)
  app.className = `app ${state.profile.reducedMotion ? 'reduce-motion' : ''}`
  app.innerHTML = `
    ${backgroundDecor()}
    ${state.screen === 'home' ? renderHome() : renderGame()}
  `
}

function brand(compact = false) {
  return `
    <div class="brand ${compact ? 'compact' : ''}">
      <span class="brand-mark"><i></i><i></i><i></i></span>
      <span><strong>LA TOUR</strong><b>DES MOTS</b></span>
    </div>
  `
}

function musicButtonMarkup() {
  const enabled = state.profile.music
  return `
    <button
      class="icon-button music-toggle ${enabled ? 'is-on' : 'is-off'}"
      data-action="music"
      aria-label="${enabled ? 'Couper la musique' : 'Activer la musique'}"
      title="${enabled ? 'Couper la musique' : 'Activer la musique'}"
    ><span aria-hidden="true">♫</span></button>
  `
}

function backgroundDecor() {
  return '<div class="background-decor" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div>'
}

function renderHome() {
  const currentWords = getWords(state.level, state.theme)
  return `
    <main class="home-shell">
      <header class="topbar home-topbar">
        ${brand()}
        <div class="top-actions">
          <button class="icon-button" data-action="help" aria-label="Règles">?</button>
          <button class="icon-button" data-action="stats" aria-label="Statistiques">★</button>
          <button class="icon-button" data-action="settings" aria-label="Réglages">⚙</button>
          ${musicButtonMarkup()}
        </div>
      </header>

      <section class="hero">
        <div class="hero-copy">
          <div class="eyebrow">LE JEU DE LETTRES QUI NE FAIT PEUR À PERSONNE</div>
          <h1>Grimpe dans<br><span>La Tour des Mots</span></h1>
          <p>Trouve le mot avant que l’échafaudage ne disparaisse. Dix pièces, dix chances… et une chute très rigolote.</p>
          <div class="hero-badges">
            <span>✓ Ludique</span>
            <span>✓ Dès 3 ans</span>
            <span>✓ Hors connexion</span>
          </div>
        </div>
        <div class="hero-visual" aria-hidden="true">
          <div class="hero-glow"></div>
          ${scaffoldMarkup(3, 'playing', true)}
        </div>
      </section>

      <section class="setup-card">
        <div class="setup-header">
          <div>
            <span class="section-kicker">1. CHOISIS TON NIVEAU</span>
            <h2>Pour qui joue-t-on ?</h2>
          </div>
          <label class="player-chip">
            <span class="avatar">${escapeHtml(state.profile.playerName ? state.profile.playerName.slice(0, 1).toUpperCase() : '☺')}</span>
            <input id="player-name" value="${escapeHtml(state.profile.playerName)}" maxlength="16" placeholder="Ton prénom" aria-label="Prénom du joueur">
          </label>
        </div>

        <div class="level-grid">
          ${Object.entries(LEVELS).map(([key, item]) => `
            <button class="level-card ${state.level === key ? 'selected' : ''}" data-level="${key}">
              <span class="level-icon">${item.icon}</span>
              <span><strong>${item.label}</strong><small>${item.subtitle}</small></span>
              <span class="radio-dot"></span>
            </button>
          `).join('')}
        </div>

        <div class="theme-heading">
          <div>
            <span class="section-kicker">2. CHOISIS UN THÈME</span>
            <h2>Quel univers aujourd’hui ?</h2>
          </div>
          <span class="word-count">${currentWords.length} mots dans ce thème</span>
        </div>

        <div class="theme-grid">
          ${Object.entries(THEMES).map(([key, item]) => `
            <button class="theme-card ${state.theme === key ? 'selected' : ''}" data-theme="${key}">
              <span>${item.icon}</span>
              <strong>${item.label}</strong>
            </button>
          `).join('')}
        </div>

        <div class="start-row">
          <div class="mini-stats">
            <div><strong>${state.profile.stars}</strong><span>étoiles</span></div>
            <div><strong>${state.profile.bestStreak}</strong><span>meilleure série</span></div>
            <div><strong>${countWords()}</strong><span>mots intégrés</span></div>
          </div>
          <button class="primary-button big" data-action="start">
            <span>Jouer maintenant</span>
            <b>→</b>
          </button>
        </div>
      </section>

      <footer class="footer-note">La Tour des Mots · Jeu familial de lettres · Les progrès restent enregistrés sur cet appareil.</footer>
    </main>
  `
}

function renderGame() {
  const piecesLeft = Math.max(0, MAX_MISTAKES - state.mistakes)
  const letters = uniqueLetters(state.word)
  const correctGuesses = state.guessed.filter(letter => letters.includes(letter)).length
  const progress = Math.round((correctGuesses / Math.max(1, letters.length)) * 100)

  return `
    <main class="game-shell">
      <header class="topbar game-topbar">
        <button class="back-button" data-action="home">← <span>Accueil</span></button>
        ${brand(true)}
        <div class="top-actions">
          <span class="score-pill">★ ${state.profile.stars}</span>
          <button class="icon-button" data-action="help" aria-label="Règles">?</button>
          <button class="icon-button" data-action="settings" aria-label="Réglages">⚙</button>
          ${musicButtonMarkup()}
        </div>
      </header>

      <section class="game-meta">
        <div class="meta-left">
          <span class="round-label">MOT ${state.round}</span>
          <span class="meta-chip">${LEVELS[state.level].icon} ${LEVELS[state.level].label}</span>
          <span class="meta-chip">${THEMES[state.theme].icon} ${THEMES[state.theme].label}</span>
        </div>
        <div class="lives-summary">
          <span>${piecesLeft}/10 pièces</span>
          <div class="life-dots">
            ${Array.from({ length: 10 }, (_, i) => `<i class="${i < piecesLeft ? 'alive' : ''}"></i>`).join('')}
          </div>
        </div>
      </section>

      <section class="game-layout">
        <div class="stage-card" id="stage-card">
          <div class="stage-sky">
            <span class="cloud cloud-a"></span>
            <span class="cloud cloud-b"></span>
            <span class="bird bird-a">⌁</span>
            <span class="bird bird-b">⌁</span>
          </div>
          ${scaffoldMarkup(state.mistakes, state.status)}
          <div class="stage-caption">${stageCaption(piecesLeft)}</div>
        </div>

        <div class="play-card">
          <div class="progress-line"><span style="width:${progress}%"></span></div>
          <div class="prompt-zone">
            <span class="tiny-label">LE MOT À TROUVER</span>
            ${wordDisplay(state.word, state.guessed, state.status !== 'playing')}
            <div class="word-info">${normalizedLetters(state.word).length} lettres · ${THEMES[state.theme].label}</div>
          </div>

          ${state.status === 'playing' ? gameControls() : resultPanel(piecesLeft)}
        </div>
      </section>

      ${state.status === 'won' ? confettiMarkup() : ''}
    </main>
  `
}

function stageCaption(piecesLeft) {
  if (state.status === 'won') return 'Bravo ! La tour tient encore debout.'
  if (state.status === 'lost') return 'Patatras ! Bibo va bien, mais son échafaudage beaucoup moins.'
  if (state.mistakes === 0) return 'Bibo compte sur toi !'
  if (state.mistakes >= 7) return 'Ouh là… ça devient bancal !'
  return `Attention, plus que ${piecesLeft} pièce${piecesLeft > 1 ? 's' : ''} !`
}

function wordDisplay(word, guessed, reveal) {
  const characters = [...word]
  const slotCount = Math.max(1, characters.length)
  const maxWidth = Math.min(680, Math.max(150, slotCount * 52))
  const densityClass = slotCount >= 16 ? 'very-compact' : slotCount >= 12 ? 'compact' : ''

  return `
    <div
      class="word-display ${densityClass}"
      style="--slot-count:${slotCount};max-width:${maxWidth}px"
      aria-label="Mot à trouver"
    >
      ${characters.map((char, index) => {
        const folded = foldChar(char)
        const punctuation = !isLetter(char)
        const visible = punctuation || guessed.includes(folded) || reveal
        return `
          <span class="letter-slot ${punctuation ? 'punctuation' : ''} ${visible ? 'visible' : ''}" data-index="${index}">
            <b>${visible ? escapeHtml(char.toUpperCase()) : ''}</b>
          </span>
        `
      }).join('')}
    </div>
  `
}

function gameControls() {
  const wordLetters = normalizedLetters(state.word)
  return `
    <div class="keyboard" aria-label="Clavier de lettres">
      ${ALPHABET.map(letter => {
        const used = state.guessed.includes(letter)
        const good = used && wordLetters.includes(letter)
        const bad = used && !good
        return `<button data-letter="${letter}" ${used ? 'disabled' : ''} class="${good ? 'good' : ''} ${bad ? 'bad' : ''}" aria-label="Lettre ${letter}">${letter}</button>`
      }).join('')}
    </div>
    <div class="hint-row">
      <button class="hint-button" data-action="hint" ${state.hintUsed ? 'disabled' : ''}>
        <span class="bulb">💡</span>
        <span>
          <strong>${state.hintUsed ? 'Indice déjà utilisé' : 'Mon indice unique'}</strong>
          <small>${state.hintUsed ? 'Une seule fois par mot' : 'Révèle une lettre · coûte 1 pièce'}</small>
        </span>
        <b>${state.hintUsed ? '✓' : '−1'}</b>
      </button>
    </div>
  `
}

function resultPanel(piecesLeft) {
  const won = state.status === 'won'
  const earned = Math.max(1, piecesLeft)
  return `
    <div class="result-panel ${won ? 'win' : 'lose'}">
      <div class="result-icon">${won ? '★' : '✦'}</div>
      <span class="tiny-label">${won ? 'BRAVO !' : 'LE MOT ÉTAIT'}</span>
      <h2>${escapeHtml(state.word.toUpperCase())}</h2>
      <p>${won
        ? `Tu sauves ${piecesLeft} pièce${piecesLeft > 1 ? 's' : ''} de la tour et gagnes ${earned} étoile${earned > 1 ? 's' : ''}.`
        : 'Bibo est tombé sur les fesses, mais il est déjà prêt à recommencer.'}</p>
      <div class="result-actions">
        <button class="secondary-button" data-action="speak">🔊 Écouter le mot</button>
        <button class="primary-button" data-action="next">Mot suivant →</button>
      </div>
      <button class="text-button" data-action="home">Changer de niveau ou de thème</button>
    </div>
  `
}

function scaffoldMarkup(mistakes, status, decorative = false) {
  const visible = index => mistakes < index
  const removed = index => visible(index) ? '' : 'removed'
  const fallen = status === 'lost'
  return `
    <div class="scaffold-scene ${fallen ? 'fallen' : ''} ${decorative ? 'decorative' : ''}">
      <div class="ground"><span></span><span></span><span></span><span></span></div>
      <div class="scaffold-piece brace-left p1 ${removed(1)}"></div>
      <div class="scaffold-piece brace-right p2 ${removed(2)}"></div>
      <div class="scaffold-piece rail-left p3 ${removed(3)}"></div>
      <div class="scaffold-piece rail-right p4 ${removed(4)}"></div>
      <div class="scaffold-piece cross-low p5 ${removed(5)}"></div>
      <div class="scaffold-piece post-left p6 ${removed(6)}"></div>
      <div class="scaffold-piece post-right p7 ${removed(7)}"></div>
      <div class="scaffold-piece cross-high p8 ${removed(8)}"></div>
      <div class="scaffold-piece top-rail p9 ${removed(9)}"></div>
      <div class="scaffold-piece platform p10 ${removed(10)}"></div>
      ${mascotMarkup(fallen, status)}
      ${fallen ? '<div class="impact-star">✦</div>' : ''}
    </div>
  `
}

function mascotMarkup(fallen, status) {
  return `
    <div class="mascot ${fallen ? 'is-fallen' : ''} ${status === 'won' ? 'is-happy' : ''}">
      <div class="mascot-shadow"></div>
      <div class="head">
        <div class="hair hair-a"></div><div class="hair hair-b"></div><div class="hair hair-c"></div>
        <span class="ear left"></span><span class="ear right"></span>
        <span class="eye left"></span><span class="eye right"></span>
        <span class="nose"></span><span class="mouth"></span>
      </div>
      <div class="body"><span class="shirt-dot">★</span></div>
      <div class="arm arm-left"><span class="hand"></span></div>
      <div class="arm arm-right"><span class="hand"></span></div>
      <div class="leg leg-left"><span class="shoe"></span></div>
      <div class="leg leg-right"><span class="shoe"></span></div>
    </div>
  `
}

function confettiMarkup() {
  return `
    <div class="confetti" aria-hidden="true">
      ${Array.from({ length: 48 }, (_, i) => {
        const x = Math.round(Math.random() * 100)
        const delay = Math.random() * 0.6
        const duration = 1.8 + Math.random() * 1.6
        const spin = Math.round(Math.random() * 540)
        return `<i style="--x:${x}vw;--delay:${delay}s;--duration:${duration}s;--spin:${spin}deg"></i>`
      }).join('')}
    </div>
  `
}

function startGame() {
  const words = getWords(state.level, state.theme)
  const next = pickRandom(words, state.lastWord)
  state.word = next
  state.lastWord = next
  state.guessed = []
  state.mistakes = 0
  state.hintUsed = false
  state.status = 'playing'
  state.round = 1
  state.screen = 'game'
  state.profile.level = state.level
  state.profile.theme = state.theme
  saveProfile()
  sound.click()
  render()
}

function nextWord() {
  const words = getWords(state.level, state.theme)
  const next = pickRandom(words, state.lastWord)
  state.word = next
  state.lastWord = next
  state.guessed = []
  state.mistakes = 0
  state.hintUsed = false
  state.status = 'playing'
  state.round += 1
  sound.click()
  render()
}

function guessLetter(letter) {
  if (state.screen !== 'game' || state.status !== 'playing' || state.guessed.includes(letter)) return

  state.guessed.push(letter)
  const wordLetters = normalizedLetters(state.word)

  if (wordLetters.includes(letter)) {
    sound.correct()
    if (uniqueLetters(state.word).every(item => state.guessed.includes(item))) {
      finishRound(true)
      return
    }
  } else {
    state.mistakes = Math.min(MAX_MISTAKES, state.mistakes + 1)
    sound.wrong()
    if (state.mistakes >= MAX_MISTAKES) {
      finishRound(false)
      return
    }
  }

  render()
  if (!wordLetters.includes(letter)) shakeStage()
}

function useHint() {
  if (state.hintUsed || state.status !== 'playing') return
  const missing = uniqueLetters(state.word).filter(letter => !state.guessed.includes(letter))
  if (!missing.length) return

  const revealed = pickRandom(missing)
  state.hintUsed = true
  state.guessed.push(revealed)
  state.mistakes = Math.min(MAX_MISTAKES, state.mistakes + 1)
  sound.wrong()

  if (state.mistakes >= MAX_MISTAKES) {
    finishRound(false)
    return
  }

  if (uniqueLetters(state.word).every(item => state.guessed.includes(item))) {
    finishRound(true)
    return
  }

  render()
  notify(`Indice : la lettre ${revealed} a été révélée`)
  shakeStage()
}

function finishRound(won) {
  if (state.status !== 'playing') return

  state.status = won ? 'won' : 'lost'
  const piecesLeft = Math.max(0, MAX_MISTAKES - state.mistakes)
  const nextStreak = won ? state.profile.streak + 1 : 0

  state.profile.games += 1
  state.profile.wins += won ? 1 : 0
  state.profile.streak = nextStreak
  state.profile.bestStreak = Math.max(state.profile.bestStreak, nextStreak)
  state.profile.stars += won ? Math.max(1, piecesLeft) : 0

  saveProfile()
  render()

  if (won) {
    setTimeout(() => sound.win(), 80)
    return
  }

  // Démarre le « wouu » presque en même temps que la chute CSS.
  // Le « pouf » d'impact est déjà programmé dans sound.fall().
  setTimeout(() => sound.fall(), 70)

  // Petit son final une fois Bibo assis et la main sur la tête.
  setTimeout(() => sound.lose(), 1420)
}

function shakeStage() {
  const stage = document.querySelector('#stage-card')
  if (!stage || state.profile.reducedMotion) return
  stage.classList.remove('shake')
  requestAnimationFrame(() => stage.classList.add('shake'))
  setTimeout(() => stage.classList.remove('shake'), 380)
}

async function speakWord() {
  const text = String(state.word || '').trim()
  if (!text) return

  const rate = state.level === 'petit' ? 0.72 : 0.88
  const musicWasOn = state.profile.music && musicRunning
  if (musicWasOn) setMusicVolume(0.08)

  // Dans l'APK, on utilise d'abord le moteur vocal natif Android.
  // Cela évite de dépendre de speechSynthesis du WebView, qui peut être absent
  // ou silencieux sur certains téléphones.
  try {
    const language = await TextToSpeech.isLanguageSupported({ lang: 'fr-FR' })
    if (language?.supported === false) {
      try { await TextToSpeech.openInstall() } catch {}
      if (musicWasOn) setMusicVolume(0.34)
      notify('La voix française doit être installée sur le téléphone')
      return
    }

    try { await TextToSpeech.stop() } catch {}
    await TextToSpeech.speak({
      text,
      lang: 'fr-FR',
      rate,
      pitch: 1.0,
      volume: 1.0,
    })
    if (musicWasOn) setMusicVolume(0.34)
    return
  } catch (nativeError) {
    console.warn('TTS natif indisponible, tentative Web Speech API', nativeError)
  }

  // Secours pour la version navigateur.
  if ('speechSynthesis' in window && 'SpeechSynthesisUtterance' in window) {
    try {
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = 'fr-FR'
      utterance.rate = rate
      utterance.pitch = 1.0
      utterance.volume = 1.0
      utterance.onend = () => { if (musicWasOn) setMusicVolume(0.34) }
      utterance.onerror = () => { if (musicWasOn) setMusicVolume(0.34) }
      window.speechSynthesis.speak(utterance)
      return
    } catch (webError) {
      console.warn('Web Speech API indisponible', webError)
    }
  }

  if (musicWasOn) setMusicVolume(0.34)
  notify('Lecture vocale indisponible : vérifie le moteur vocal Android')
}

function openModal(type) {
  overlayRoot.innerHTML = modalMarkup(type)
}

function closeModal() {
  overlayRoot.innerHTML = ''
}

function modalMarkup(type) {
  if (type === 'help') {
    return modalShell('Comment jouer ?', `
      <div class="rules-list">
        <div><span>1</span><p><strong>Choisis une lettre.</strong> Si elle se trouve dans le mot, elle apparaît.</p></div>
        <div><span>2</span><p><strong>Une mauvaise lettre retire une pièce</strong> de l’échafaudage.</p></div>
        <div><span>3</span><p><strong>Tu as 10 pièces.</strong> À la dixième erreur, la plateforme disparaît et Bibo tombe sur les fesses.</p></div>
        <div><span>4</span><p><strong>Un seul indice par mot.</strong> Il révèle une bonne lettre mais coûte lui aussi une pièce.</p></div>
        <div><span>5</span><p><strong>Trouve le mot avant la chute</strong> pour gagner des étoiles. Plus il reste de pièces, plus tu en gagnes.</p></div>
      </div>
    `)
  }

  if (type === 'stats') {
    const rate = state.profile.games ? Math.round((state.profile.wins / state.profile.games) * 100) : 0
    return modalShell('Mes exploits', `
      <div class="stats-grid">
        <div><span>★</span><strong>${state.profile.stars}</strong><small>Étoiles</small></div>
        <div><span>✓</span><strong>${state.profile.wins}</strong><small>Victoires</small></div>
        <div><span>♜</span><strong>${state.profile.games}</strong><small>Parties</small></div>
        <div><span>⚡</span><strong>${state.profile.bestStreak}</strong><small>Meilleure série</small></div>
      </div>
      <div class="rate-card"><span>Taux de réussite</span><strong>${rate}%</strong><div><i style="width:${rate}%"></i></div></div>
      <button class="danger-link" data-action="reset-stats">Remettre les statistiques à zéro</button>
    `)
  }

  return modalShell('Réglages', `
    <div class="settings-list">
      <label>
        <span><strong>Effets sonores</strong><small>Sons des lettres, de la victoire et de la chute</small></span>
        <input id="sound-toggle" type="checkbox" ${state.profile.sound ? 'checked' : ''}>
      </label>
      <label>
        <span><strong>Musique de fond</strong><small>Mélodie rétro jouée en boucle pendant la partie</small></span>
        <input id="music-toggle-setting" type="checkbox" ${state.profile.music ? 'checked' : ''}>
      </label>
      <label>
        <span><strong>Réduire les animations</strong><small>Pour un affichage plus calme</small></span>
        <input id="motion-toggle" type="checkbox" ${state.profile.reducedMotion ? 'checked' : ''}>
      </label>
    </div>
    <p class="privacy-note">Aucun compte n’est nécessaire. Le prénom et les statistiques sont enregistrés uniquement dans le navigateur de cet appareil.</p>
  `)
}

function modalShell(title, body) {
  return `
    <div class="modal-backdrop" data-action="backdrop-close">
      <div class="modal-card" role="dialog" aria-modal="true" aria-label="${escapeHtml(title)}">
        <div class="modal-head"><h2>${escapeHtml(title)}</h2><button data-action="close-modal" aria-label="Fermer">×</button></div>
        ${body}
      </div>
    </div>
  `
}

function resetStats() {
  state.profile.games = 0
  state.profile.wins = 0
  state.profile.streak = 0
  state.profile.bestStreak = 0
  state.profile.stars = 0
  saveProfile()
  openModal('stats')
  render()
  notify('Statistiques remises à zéro')
}

app.addEventListener('click', event => {
  const levelButton = event.target.closest('[data-level]')
  if (levelButton) {
    state.level = levelButton.dataset.level
    sound.click()
    render()
    return
  }

  const themeButton = event.target.closest('[data-theme]')
  if (themeButton) {
    state.theme = themeButton.dataset.theme
    sound.click()
    render()
    return
  }

  const letterButton = event.target.closest('[data-letter]')
  if (letterButton) {
    guessLetter(letterButton.dataset.letter)
    return
  }

  const actionButton = event.target.closest('[data-action]')
  if (!actionButton) return

  switch (actionButton.dataset.action) {
    case 'start': startGame(); break
    case 'home': state.screen = 'home'; sound.click(); render(); break
    case 'next': nextWord(); break
    case 'hint': useHint(); break
    case 'speak': speakWord(); break
    case 'help': openModal('help'); break
    case 'stats': openModal('stats'); break
    case 'settings': openModal('settings'); break
    case 'music': toggleBackgroundMusic(); break
  }
})

app.addEventListener('input', event => {
  if (event.target.id === 'player-name') {
    state.profile.playerName = event.target.value.slice(0, 16)
    saveProfile()
    const avatar = document.querySelector('.player-chip .avatar')
    if (avatar) avatar.textContent = state.profile.playerName ? state.profile.playerName.slice(0, 1).toUpperCase() : '☺'
  }
})

overlayRoot.addEventListener('click', event => {
  const action = event.target.closest('[data-action]')?.dataset.action
  if (action === 'close-modal') closeModal()
  if (action === 'reset-stats') resetStats()
  if (action === 'backdrop-close' && event.target.classList.contains('modal-backdrop')) closeModal()
})

overlayRoot.addEventListener('change', event => {
  if (event.target.id === 'sound-toggle') {
    state.profile.sound = event.target.checked
    saveProfile()
  }
  if (event.target.id === 'music-toggle-setting') {
    state.profile.music = event.target.checked
    saveProfile()
    if (state.profile.music) startBackgroundMusic(true)
    else stopBackgroundMusic()
    render()
  }
  if (event.target.id === 'motion-toggle') {
    state.profile.reducedMotion = event.target.checked
    saveProfile()
    render()
  }
})

window.addEventListener('keydown', event => {
  if (event.key === 'Escape' && overlayRoot.innerHTML) {
    closeModal()
    return
  }
  if (state.screen !== 'game' || state.status !== 'playing') return
  const key = foldChar(event.key)
  if (/^[A-Z]$/.test(key)) guessLetter(key)
})

// Android bloque la lecture automatique avant la première interaction.
// Dès le premier toucher, la musique démarre si elle est activée.
window.addEventListener('pointerdown', () => {
  if (state.profile.music) startBackgroundMusic()
}, { passive: true })

window.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') stopBackgroundMusic()
  else if (state.profile.music) startBackgroundMusic()
})

render()
