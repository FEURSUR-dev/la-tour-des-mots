export const THEMES = {
  animaux: { label: 'Animaux', icon: '🐾' },
  nature: { label: 'Nature', icon: '🌿' },
  nourriture: { label: 'À table', icon: '🍓' },
  maison: { label: 'Maison', icon: '🏠' },
  ecole: { label: 'École & objets', icon: '✏️' },
  mer: { label: 'Mer & bateaux', icon: '⛵' },
  sports: { label: 'Sports', icon: '⚽' },
  espace: { label: 'Espace', icon: '🚀' },
  metiers: { label: 'Métiers', icon: '🧑‍🚒' },
  monde: { label: 'Monde & culture', icon: '🌍' },
}

export const LEVELS = {
  petit: {
    label: '3 ans',
    subtitle: 'Mots très courts et familiers',
    icon: '🌈',
  },
  enfant: {
    label: '5 à 10 ans',
    subtitle: 'Mots variés pour apprendre en jouant',
    icon: '🧠',
  },
  adulte: {
    label: 'Adulte',
    subtitle: 'Mots plus longs et plus exigeants',
    icon: '🏆',
  },
}

export const WORDS = {
  petit: {
    animaux: ['chat','chien','lion','ours','loup','âne','rat','coq','poule','canard','lapin','vache','mouton','singe','panda','zèbre','lama','baleine','requin','crabe','mouche','fourmi','abeille','ver','cerf'],
    nature: ['eau','air','mer','lac','île','ciel','soleil','lune','pluie','vent','feu','bois','arbre','fleur','rose','herbe','sable','roche','terre','neige','nuage','fruit','graine','feuille','jardin'],
    nourriture: ['pain','lait','riz','œuf','pomme','poire','fraise','kiwi','melon','miel','jus','eau','soupe','pâte','pizza','cake','tarte','glace','sel','sucre','cacao','maïs','thon','olive','noix'],
    maison: ['lit','mur','sol','toit','porte','clé','table','chaise','verre','bol','tasse','four','bain','savon','lampe','tapis','livre','radio','photo','sac','robe','pull','botte','jouet','drap'],
    ecole: ['mot','nom','jeu','dé','bille','colle','craie','feutre','gomme','stylo','livre','page','carte','règle','sac','table','classe','école','lettre','chiffre','forme','rond','carré','ligne','image'],
    mer: ['mer','eau','île','port','quai','mât','voile','barre','coque','ancre','rame','bouée','phare','plage','sable','vague','thon','crabe','poisson','requin','canot','bateau','corde','filet','lagon'],
    sports: ['jeu','but','ballon','vélo','ski','judo','foot','golf','surf','danse','course','balle','corde','saut','nage','stade','équipe','piste','filet','raquette','médaille','coach','score','match','pneu'],
    espace: ['lune','soleil','ciel','mars','terre','fusée','étoile','robot','ovni','comète','espace','monde','nuit','jour','bleu','saturne','anneau','casque','radio','base','alien','orbite','laser','sonde','astre'],
    metiers: ['chef','papa','maman','prof','marin','pilote','juge','agent','guide','artiste','acteur','pompier','docteur','maçon','fermier','coiffeur','vendeur','facteur','danseur','gardien','cuisinier','pêcheur','policier','chanteur','peintre'],
    monde: ['pays','ville','route','pont','parc','gare','train','taxi','bus','avion','hôtel','carte','drapeau','fête','musée','film','cirque','danse','chant','radio','photo','livre','église','marché','place'],
  },
  enfant: {
    animaux: ['éléphant','girafe','crocodile','dauphin','manchot','kangourou','écureuil','hérisson','tortue','léopard','guépard','gorille','chameau','flamant','pélican','pieuvre','méduse','hippocampe','papillon','coccinelle','libellule','scarabée','hamster','perroquet','autruche','rhinocéros','hippopotame','orque','morue','marlin','espadon','moustique','araignée','escargot','grenouille'],
    nature: ['volcan','rivière','cascade','montagne','vallée','forêt','océan','désert','prairie','falaise','corail','lagon','tempête','orage','arc-en-ciel','brouillard','goutte','racine','branche','écorce','pétale','bourgeon','mousse','bambou','cocotier','bananier','mangrove','source','rivage','horizon','saison','climat','courant','marée','éclair'],
    nourriture: ['chocolat','vanille','banane','ananas','mangue','orange','citron','carotte','tomate','salade','haricot','fromage','yaourt','beurre','céréale','biscuit','gâteau','crêpe','gaufre','bonbon','sandwich','omelette','poulet','saumon','crevette','brocoli','avocat','confiture','noisette','amande','cerise','pastèque','framboise','compote','limonade'],
    maison: ['fenêtre','cuisine','chambre','salon','garage','jardin','escalier','placard','tiroir','oreiller','matelas','couette','miroir','serviette','douche','lavabo','robinet','casserole','fourchette','cuillère','assiette','bouilloire','frigo','balai','aspirateur','machine','canapé','armoire','bureau','horloge','rideau','coussin','terrasse','portail','sonnette'],
    ecole: ['cartable','cahier','crayon','compas','équerre','ciseaux','trousse','tableau','maître','maîtresse','élève','leçon','devoir','calcul','lecture','poésie','histoire','science','dessin','musique','récréation','cantine','gymnase','bibliothèque','alphabet','voyelle','consonne','phrase','nombre','addition','division','géométrie','planète','expérience','question'],
    mer: ['capitaine','matelot','marin','navire','vedette','pirogue','voilier','chalutier','cargo','paquebot','gouvernail','hélice','moteur','amarre','cordage','ponton','jetée','balise','boussole','compas','jumelles','cabine','pont','cale','caleçon','filet','casier','palangre','plongeur','dauphin','baleine','marée','courant','récif','atoll'],
    sports: ['football','basket','handball','volley','tennis','natation','athlète','gymnastique','escalade','équitation','karaté','boxe','rugby','badminton','skateboard','trottinette','plongée','voile','kayak','pétanque','marathon','sprinter','gardien','arbitre','maillot','terrain','tribune','podium','trophée','victoire','défaite','entraînement','champion','relais','plongeon'],
    espace: ['astronaute','galaxie','univers','planète','mercure','vénus','jupiter','saturne','uranus','neptune','météorite','astéroïde','satellite','télescope','navette','station','orbite','gravité','cratère','cosmos','éclipse','constellation','lumière','fusée','capsule','mission','robot','sonde','comète','étoile','soleil','lune','terre','mars','spatial'],
    metiers: ['enseignant','médecin','infirmier','pompier','policier','boulanger','pâtissier','cuisinier','serveur','mécanicien','plombier','électricien','menuisier','architecte','ingénieur','journaliste','photographe','musicien','chanteur','comédien','dentiste','vétérinaire','pharmacien','agriculteur','jardinier','chauffeur','conducteur','capitaine','marin','pilote','astronaute','scientifique','libraire','couturier','coiffeur'],
    monde: ['continent','océan','capitale','frontière','village','monument','pyramide','château','temple','mosquée','cathédrale','statue','fontaine','théâtre','cinéma','orchestre','concert','festival','carnaval','voyage','valise','passeport','aéroport','métro','tramway','autoroute','tunnel','bibliothèque','restaurant','boutique','hôpital','stadium','tradition','langue','culture'],
  },
  adulte: {
    animaux: ['ornithorynque','axolotl','pangolin','narval','okapi','tapir','caracal','suricate','mangouste','capybara','wombat','échidné','gibbon','macaque','babouin','chinchilla','tatou','glouton','martre','hermine','albatros','cormoran','balbuzard','martin-pêcheur','calmar','seiche','nautile','barracuda','cœlacanthe','esturgeon','mygale','phasme','mante-religieuse','luciole','salamandre'],
    nature: ['photosynthèse','biodiversité','écosystème','géothermie','précipitation','évaporation','condensation','stratosphère','troposphère','tectonique','sédiment','érosion','aquifère','pergélisol','mousson','cyclone','anticyclone','isobare','bioluminescence','métamorphisme','stalactite','stalagmite','estuaire','delta','archipel','péninsule','isthme','pluviométrie','chlorophylle','pollinisation','germination','humidité','salinité','altitude','latitude'],
    nourriture: ['gastronomie','fermentation','pasteurisation','caramélisation','émulsion','marinade','vinaigrette','ratatouille','bouillabaisse','cassoulet','choucroute','risotto','carbonara','guacamole','tiramisu','millefeuille','pistache','cardamome','coriandre','curcuma','gingembre','cannelle','muscade','safran','artichaut','aubergine','courgette','betterave','pamplemousse','grenadine','nectarine','myrtille','groseille','champignon','mozzarella'],
    maison: ['architecture','domotique','charpente','isolation','ventilation','climatisation','fondation','maçonnerie','menuiserie','plomberie','électricité','interrupteur','disjoncteur','canalisation','gouttière','toiture','mezzanine','véranda','balustrade','parquet','carrelage','tapisserie','bibliothèque','commode','vaisselier','réfrigérateur','lave-vaisselle','micro-ondes','aspirateur','thermostat','serrurerie','buanderie','grenier','soupirail','cloison'],
    ecole: ['épistémologie','mathématiques','philosophie','littérature','linguistique','géographie','astronomie','biologie','physique','chimie','algorithme','équation','probabilité','statistique','démonstration','hypothèse','expérience','bibliographie','grammaire','orthographe','conjugaison','sémantique','métaphore','allégorie','argumentation','dissertation','chronologie','civilisation','anthropologie','sociologie','psychologie','cartographie','géométrie','trigonométrie','logarithme'],
    mer: ['navigation','échouement','déséchouage','amarrage','mouillage','franc-bord','stabilité','assiette','gouvernail','propulsion','timonerie','passerelle','compartiment','étanchéité','ballast','carène','déplacement','tirant-d’eau','cabestan','guindeau','aussière','chaumard','bitte','bollard','pantoire','palangrier','senneur','chalutage','bathymétrie','hydrographie','océanographie','météorologie','sémaphore','radiobalise','transbordement'],
    sports: ['décathlon','heptathlon','triathlon','biathlon','pentathlon','haltérophilie','gymnastique','athlétisme','cyclisme','escrime','aviron','canoë-kayak','parapente','alpinisme','spéléologie','planche-à-voile','kitesurf','water-polo','taekwondo','judo','jiu-jitsu','badminton','squash','cricket','baseball','handball','volleyball','basketball','motocross','endurance','qualification','prolongation','chronomètre','arbitrage','compétition'],
    espace: ['astrophysique','cosmologie','exoplanète','supernova','nébuleuse','quasar','pulsar','magnétar','trou-noir','gravitation','relativité','spectroscopie','héliosphère','magnétosphère','ionosphère','exosphère','apogée','périgée','aphélie','périhélie','équateur','équinoxe','solstice','constellation','astéroïde','météoroïde','satellite','télémétrie','propulseur','cosmonaute','microgravité','radiotélescope','interstellaire','extraterrestre','cosmodrome'],
    metiers: ['océanographe','hydrographe','météorologue','astrophysicien','archéologue','anthropologue','géophysicien','toxicologue','épidémiologiste','urbaniste','ergonome','cryptographe','développeur','administrateur','magistrat','notaire','huissier','commissaire','contrôleur','inspecteur','conducteur','mécanicien','électromécanicien','chaudronnier','soudeur','charpentier','ébéniste','horticulteur','apiculteur','viticulteur','sommelier','scénariste','réalisateur','compositeur','traducteur'],
    monde: ['géopolitique','démographie','mondialisation','industrialisation','urbanisation','civilisation','patrimoine','archéologie','renaissance','antiquité','préhistoire','constitution','démocratie','république','monarchie','diplomatie','ambassade','parlement','souveraineté','territoire','diaspora','migration','navigation','exploration','cartographie','longitude','méridien','hémisphère','topographie','métropole','mégalopole','infrastructure','architecture','calligraphie','mythologie'],
  },
}

export function getWords(level, theme) {
  return WORDS[level]?.[theme] ?? []
}

export function countWords() {
  return Object.values(WORDS).reduce((total, byTheme) => {
    return total + Object.values(byTheme).reduce((sum, list) => sum + list.length, 0)
  }, 0)
}
