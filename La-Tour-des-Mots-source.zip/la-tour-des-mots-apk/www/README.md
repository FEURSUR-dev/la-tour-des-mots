# La Tour des Mots

Application web familiale inspirée du jeu du pendu, sans pendaison : dix pièces d'un échafaudage sont retirées progressivement. À la dixième mauvaise réponse, la plateforme disparaît et Bibo tombe sur les fesses avant de se frotter la tête.

## Fonctions

- 3 niveaux : 3 ans, 5 à 10 ans, adulte
- 10 thèmes
- grande banque de mots intégrée dans `data/words.js`
- 10 mauvaises réponses maximum
- 1 indice unique par mot : il révèle une lettre et coûte 1 pièce
- échafaudage en 10 éléments
- animation comique de chute
- clavier tactile + clavier physique
- sons activables/désactivables
- lecture vocale du mot si le navigateur la prend en charge
- confettis en cas de victoire
- étoiles, victoires et séries enregistrées dans le navigateur
- responsive téléphone/tablette/ordinateur
- installable comme application web sur les navigateurs compatibles
- fonctionnement possible hors connexion après une première ouverture
- aucune dépendance, aucun serveur et aucune compilation

## Structure

```text
la-tour-des-mots/
├── data/
│   └── words.js
├── .nojekyll
├── app.js
├── icon.svg
├── index.html
├── manifest.webmanifest
├── README.md
├── styles.css
└── sw.js
```

## Publication GitHub Pages depuis le site GitHub

1. Créer un nouveau dépôt, par exemple `la-tour-des-mots`.
2. Le mettre en **Public** si vous utilisez GitHub Free.
3. Ouvrir le dépôt puis choisir **Add file > Upload files**.
4. Envoyer tous les fichiers et le dossier `data` en conservant cette structure.
5. Valider avec **Commit changes**.
6. Ouvrir **Settings > Pages**.
7. Dans **Build and deployment**, choisir **Deploy from a branch**.
8. Choisir la branche **main** et le dossier **/(root)** puis **Save**.
9. GitHub construit et publie le site. L'adresse publique apparaît ensuite dans **Settings > Pages**.

## Modifier l'application

- Styles et animations : `styles.css`
- Logique du jeu : `app.js`
- Banque de mots : `data/words.js`
- Icône : `icon.svg`
- Informations d'installation : `manifest.webmanifest`

## Ajouter des mots

Dans `data/words.js`, chaque niveau (`petit`, `enfant`, `adulte`) possède les mêmes thèmes. Ajouter simplement les mots dans le tableau voulu.

Exemple :

```js
animaux: ['chat', 'chien', 'lion', 'panda']
```

Les accents sont affichés normalement. Le clavier accepte les lettres sans accent : par exemple `E` peut révéler `É`.
