import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const isWindows = process.platform === 'win32';
const npx = isWindows ? 'npx.cmd' : 'npx';
const node = process.execPath;

function run(command, args, options = {}) {
  const result = spawnSync(command, args, {
    stdio: 'inherit',
    shell: false,
    ...options,
  });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

if (!existsSync('android')) {
  console.log('Création du projet Android Capacitor…');
  run(npx, ['cap', 'add', 'android']);
}

console.log('Synchronisation des fichiers du jeu…');
run(npx, ['cap', 'sync', 'android']);

console.log('Application de l’icône La Tour des Mots…');
run(node, ['scripts/brand-android.mjs']);

console.log('Projet Android prêt.');
