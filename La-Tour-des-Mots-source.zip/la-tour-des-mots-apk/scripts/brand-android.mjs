import { cpSync, existsSync, mkdirSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const source = 'resources/android';
const target = 'android/app/src/main/res';

if (!existsSync(target)) {
  console.error('Le dossier Android n’existe pas encore. Lance npm run android:prepare.');
  process.exit(1);
}

function copyTree(src, dst) {
  mkdirSync(dst, { recursive: true });
  for (const name of readdirSync(src)) {
    const a = join(src, name);
    const b = join(dst, name);
    if (statSync(a).isDirectory()) copyTree(a, b);
    else cpSync(a, b, { force: true });
  }
}

copyTree(source, target);
