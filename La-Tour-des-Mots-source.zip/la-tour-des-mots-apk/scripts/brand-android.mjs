import { cpSync, existsSync, mkdirSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

const source = 'resources/android';
const target = 'android/app/src/main/res';

if (!existsSync(target)) {
  console.error('Le dossier Android natif est introuvable : ' + target);
  console.error('La commande "npx cap add android" doit être exécutée avant le branding.');
  process.exit(1);
}

// Les ressources personnalisées sont facultatives pour la compilation.
// Si elles manquent, Capacitor conserve ses ressources Android par défaut
// au lieu de faire échouer toute la génération de l'APK.
if (!existsSync(source)) {
  console.warn('Avertissement : resources/android est absent.');
  console.warn('Compilation poursuivie avec les ressources Android par défaut.');
  process.exit(0);
}

function copyTree(src, dst) {
  mkdirSync(dst, { recursive: true });
  for (const name of readdirSync(src)) {
    const from = join(src, name);
    const to = join(dst, name);
    if (statSync(from).isDirectory()) {
      copyTree(from, to);
    } else {
      cpSync(from, to, { force: true });
    }
  }
}

copyTree(source, target);
console.log('Icônes Android personnalisées appliquées.');
