import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';

function run(command, args, options = {}) {
  const result = spawnSync(command, args, { stdio: 'inherit', shell: false, ...options });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

run(process.execPath, ['scripts/prepare-android.mjs']);

const gradle = process.platform === 'win32' ? 'gradlew.bat' : './gradlew';
run(gradle, ['assembleDebug'], { cwd: 'android' });

const apk = 'android/app/build/outputs/apk/debug/app-debug.apk';
if (!existsSync(apk)) {
  console.error(`APK introuvable : ${apk}`);
  process.exit(1);
}
console.log(`\nAPK créé : ${apk}`);
